SHADOW STRIKE: MODERN WARFARE — ANDROID WRAPPER PROJECT
Version 0.1.0 — Android-only/free-tools build route

WHAT THIS PROJECT DOES
- Packages the existing browser prototype into a simple Android WebView app.
- Uses the Android system WebView and loads game assets from app/src/main/assets/index.html.
- The 3D engine in index.html is currently loaded from jsDelivr, so the game requires internet access to load Three.js. This is a prototype wrapper, not a native 3D engine build.
- The build workflow creates a DEBUG APK. It is for personal testing, not direct Play Store release.

ANDROID PHONE-ONLY BUILD INSTRUCTIONS (FREE ROUTE)
This project includes a GitHub Actions workflow so you can request a build using your Android browser; no local computer or Android Studio is required for this route.

1. Sign in or create a GitHub account in your phone browser.
2. Create a new repository, e.g. shadow-strike-android. Public repositories can use GitHub Actions free allowances, subject to GitHub's current limits. Do not upload passwords or signing keys.
3. Upload all files/folders from this project ZIP to the repository, preserving the folder structure. GitHub's website can upload files; for folders, use the mobile browser's desktop-site mode or upload files individually. Ensure .github/workflows/build-apk.yml is present.
4. Commit the files to the main branch.
5. Open the repository's Actions tab, choose "Build Shadow Strike APK", press "Run workflow" if needed, and wait for the workflow to finish successfully.
6. Open the completed workflow run. Under Artifacts, download "shadow-strike-debug-apk.zip" (GitHub stores the APK as a zipped artifact). Extract it and install app-debug.apk on your Android phone.
7. If Android blocks installation, only allow your browser/file manager to install unknown apps if you trust the APK you built yourself. Turn that permission back off afterward.

TROUBLESHOOTING
- If Actions fail, open the failed run and inspect the first red error. Common causes include missed files or a workflow YAML indentation problem.
- GitHub may ask you to verify your account or enable Actions.
- This project currently uses Android Gradle Plugin 8.6.1, Gradle 8.7, Java 17, compile SDK 35.
- If Google Play requires a newer target SDK by the time you publish, update targetSdk and test again.

BEFORE GOOGLE PLAY RELEASE
- Google Play normally expects a signed Android App Bundle (.aab) for new apps; a debug APK is not a store release artifact.
- You need a Google Play Console developer account, which has a registration fee (check Google's current official price/terms). This cannot be replaced by a free build tool.
- You must sign a release build securely, complete store listing, content rating, data safety/privacy disclosures, and meet current testing/verification rules.
- Do not publish until the app has been tested on multiple real devices and the game's privacy/data disclosures match its actual behavior.
- Ads or purchases require additional SDK integration, consent/privacy work, and payment setup; they are not included in this prototype.
- The name “Shadow Strike: Modern Warfare” is a working title. Check trademark and store-name availability before commercial release.

FILES
app/src/main/assets/index.html       Game prototype
app/src/main/java/.../MainActivity.java Android WebView shell
app/src/main/AndroidManifest.xml     App permissions and launcher activity
app/build.gradle                     Android app build settings
.github/workflows/build-apk.yml      Cloud APK build workflow
