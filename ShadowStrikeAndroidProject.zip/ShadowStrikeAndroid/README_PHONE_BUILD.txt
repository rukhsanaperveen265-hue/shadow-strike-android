SHADOW STRIKE: MODERN WARFARE — ANDROID APK BUILD KIT

This is an Android WebView wrapper around the first playable prototype. It is a buildable source project, not a prebuilt APK.

PHONE-ONLY BUILD PATH (free tools, requires a GitHub account and internet):
1. Download and extract this ZIP on your Android phone.
2. In your browser, create a new repository on GitHub named ShadowStrikeAndroid.
3. Upload the extracted project files and folders into the repository root. Make sure .github/workflows/build-apk.yml is present (GitHub's upload UI may hide dot-folders; if so, use GitHub's web editor to create that workflow file, or upload with a browser that shows hidden files).
4. Commit to the main branch. Open the repository's Actions tab. Select "Build Shadow Strike APK" if needed and run the workflow, or wait for the push-triggered build.
5. When the workflow finishes successfully, open that run and download the artifact named shadow-strike-debug-apk.
6. Extract the downloaded artifact ZIP to obtain app-debug.apk. Open the APK on your phone and approve installation from that source if Android asks.

REQUIREMENTS / LIMITS:
- No computer is required for the GitHub Actions cloud build, but GitHub account, internet, and browser uploads are required.
- The app currently loads Three.js from jsDelivr at runtime, so internet is required to load the 3D engine.
- This is a debug APK for testing only. Do not publish this debug APK as your production Play Store release.
- For Google Play, build a signed Android App Bundle (AAB), configure release signing securely, complete Play Console setup and verification, meet the current testing requirements, provide a privacy policy/data-safety disclosures as applicable, and pass review. Play Console registration may require a fee.
- This is a prototype and has not been tested on all Android devices. Use only your own original assets and comply with Google Play policies.
